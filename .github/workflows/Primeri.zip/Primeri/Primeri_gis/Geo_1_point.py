# Import necessary geometric objects from shapely module
#Point
from shapely.geometry import Point, LineString, Polygon
# Create Point geometric object(s) with coordinates
point1 = Point(2.2, 4.2)
point2 = Point(7.2, -25.1)
point3 = Point(9.26, -2.456)
point3D = Point(9.26, -2.456, 0.57)

# What is the type of the point?
point_type = type(point1)
#Let’s see what the variables look like

print(point1)
print(point3D)
print(type(point1))

#Point attributes and functions
#Extracting the coordinates of a Point can be done in a couple of different ways
# Get the coordinates
point_coords = point1.coords
print(point_coords)

# What is the type of this?
type(point_coords)
print(type(point_coords))

#Let’s see how we can get out the actual coordinates:
# Get x and y coordinates
xy = point_coords.xy

# Get only x coordinates of Point1
x = point1.x

# Whatabout y coordinate?
y = point1.y

print(xy)
print(x)
print(y)
# Calculate the distance between point1 and point2
point_dist = point1.distance(point2)
print("Distance between the points is {0:.2f} decimal degrees".format(point_dist))
