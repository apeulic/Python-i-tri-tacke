from shapely.geometry import Point
import pandas as pd
import geopandas as gpd
from fiona.crs import from_epsg
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np


#ucitavanje shape fajla
# file = "Opstine SRB projekat.shp"
opstine= gpd.read_file(file)
print(opstine)

#provera tipa fajla koji smo uneli
type(opstine)

#provera da li je nas fajl u koordinatnom sistemu MGI 1901/Balkans zona 7 EPSG:6316
opstine.crs
print(opstine.crs)

#brisanje nepotrebne kolone Opstine_lat iz atributne tabele
brisanje = gpd.GeoDataFrame(opstine)
del opstine['Optine_lat']
print(opstine)



#dodavanje kolone Povrsina u okvir atributne tabele i smestanje podataka o povrsinama svake opstine u Srbiji izrazene u kilometrima kvadratnih
opstine['Povrsina'] = opstine.area/1000000
print(opstine)

#dodavanje kolone Gustina rasprosranjenosti

opstine['Gustina rasprosranjenosti']=opstine['br_jedinki']/opstine['Povrsina']
print(opstine)

#dodavanje kolone Tip gustine
opstine['Tip gustine'] = None
print(opstine)

# odredjivanje Tipa gustine na osnovu skale 0-25 jedinki po kilometru kvadratnom - Niska,
#25-50 srednje niska, 
#50-75 - srednja, 
#75-100 srednje visoka i 
#100-200 visoka

df =gpd.GeoDataFrame(opstine)
df.loc[df['Gustina rasprosranjenosti'] < 25, 'Tip gustine'] = 'Niska'
df.loc[df['Gustina rasprosranjenosti'] > 25, 'Tip gustine'] = 'Srednje niska'
df.loc[df['Gustina rasprosranjenosti'] > 50, 'Tip gustine'] = 'Srednja'
df.loc[df['Gustina rasprosranjenosti'] > 75, 'Tip gustine'] = 'Srednje visoka'
df.loc[df['Gustina rasprosranjenosti'] > 100, 'Tip gustine'] = 'Visoka'
#######################################################
#dodavanje kolone Tip gustine_broj
opstine['Tip gustine_broj'] = None
print(opstine)

# odredjivanje Tipa gustine rasprostranjenosti
# - Niska,0
#25-50 srednje niska,1
#50-75 - srednja, 2
#75-100 srednje visoka 3
#100-200 visoka, 4

df = gpd.GeoDataFrame(opstine)
df.loc[df['Gustina rasprosranjenosti'] < 25, 'Tip gustine_broj'] = 0
df.loc[df['Gustina rasprosranjenosti'] > 25, 'Tip gustine_broj'] = 1
df.loc[df['Gustina rasprosranjenosti'] > 50, 'Tip gustine_broj'] = 2
df.loc[df['Gustina rasprosranjenosti'] > 75, 'Tip gustine_broj'] = 3
df.loc[df['Gustina rasprosranjenosti'] > 100,'Tip gustine_broj'] = 4
#######################################################
print(df)
print(opstine)

#prikaz mape
opstine.plot(column='Tip gustine', categorical=True, legend=True, figsize=(20,20),cmap="Blues")

plt.title('Gusttna  jedinki divljaci  ')
plt.show()


#snimanje dobijenog fajla na disk
izlaz= "Mapa gustine .shp"
opstine.to_file(izlaz)
