#Projekat merne stanice u Beogradu

from shapely.geometry import Point
import geopandas as gpd
from fiona.crs import from_epsg
import matplotlib.pyplot as plt

#Ubacivanje tacaka-koordinata, svaka tacka predstavlja jednu toplanu

t_1 = Point(7457264, 4956249)
t_2 = Point(7454151, 4954792)
t_3 = Point(7454149, 4959597)
t_4 = Point(7463725, 4963451)
t_5 = Point(7463540, 4960590)
t_6 = Point(7458462, 4964893)
t_7 = Point(7453836, 4961861)
t_8= Point(7459817, 4956731)
t_9= Point(7461916, 4960250)
t_10 = Point(7460551, 4958996)
t_11 = Point(7452338, 4966795)

#Provera tipa objekta
tip_tacke = type(t_1)
print(t_1)

#Kreiranje liste

lista = [(t_1, "Tacka_1"), (t_2, "Tacka_2"),( (t_3, "Tacka_3")), ((t_4, "Tacka_4")),
                ((t_5, "Tacka_5")),((t_6, "Tacka_6")),((t_7, "Tacka_7")), ((t_8, "Tacka_8")),
                ((t_9, "Tacka_9")),((t_10, "Tacka_10")),((t_11, "Tacka_11"))]


prostor= gpd.GeoDataFrame()
prostor['geometry'] = None

for ID, (tacka,naziv) in enumerate(lista):
    prostor.loc[ID, 'geometry'] = tacka
    prostor.loc[ID, 'Naziv tacke'] = naziv

#Ucitavanje i podesavanje koo. sistema (pravougle koordinate= epsg 6316)

prostor.crs = from_epsg(6316)
prostor.plot(facecolor='red');
plt.title("Merne tacke")
plt.show()

#Ubacivanje shp fajla- bg opstine i izracunavanje povrsine svake opstine

fp = "Shp\Bg_opstine.shp"

#Citanje fajla

prostor_poly = gpd.read_file(fp)
prostor_poly

#Provera trenutnog koordinatnog sistema

prostor_poly.crs
print(prostor_poly.crs)

prostor_poly['geometry'].head()
print(prostor_poly['geometry'].head())

#Preimenovanje atributa

prostor_poly = prostor_poly.rename(columns={'Naziv': 'Naziv opstine'})
prostor_poly.columns
print(prostor_poly)

#Dodat novi atribut povrsina za svaki red

prostor_poly ['area'] = None
for povrsina, row in prostor_poly .iterrows():
    prostor_poly .loc[povrsina, 'area'] = row['geometry'].area
print(prostor_poly ['area'].head())
print("Povrsine su jednake:", prostor_poly )

prostor_poly .crs = from_epsg(6316)
prostor_poly .crs
print(prostor_poly .crs)


#Prikaz karte  opstina

prostor_poly.plot(column='Naziv opstine', cmap='hsv');

#Dodavanje naslova

plt.title("Bg opstine");
plt.tight_layout()
plt.show()


#Spajanje podataka samo kao prikaz
#Provera u kojem koordinatnom sistemu se nalaze podaci

print(prostor.crs)
print(prostor_poly.crs)
prostor.to_crs(prostor_poly.crs, inplace=True)

spojeno = prostor.geometry.append(prostor_poly.geometry)

print(spojeno.crs)
print(spojeno)

#Prikaz mernih stanica na teritoriji  Beograda

spojeno.plot(cmap="hsv")
plt.title("Merne tacke na teritoriji Beograda")
plt.show()













