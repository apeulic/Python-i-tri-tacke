#Import libraries:
from scipy.linalg import eig
import numpy as np
import matplotlib.pyplot as plt
#
#Obtain the eigenval ue and eigenvector:
# Generate a 2x2 matrix.
A = [[1, 2],
     [2, 1]]
print(A)
evals, evecs = eig(A) # Calculate the eigenvalue (evals ) and eigenvector evecs ) of A
evecs = evecs[:, 0], evecs[:, 1]
'''
The plt.subplots() function returns a figure instance named fig and an
AxesSubplot instance named ax . The fig parameter indicates the entire figure, and
ax indicates the coordinate axis. Plotting:'''
fig, ax = plt.subplots()
#Make the coordinate axis pass the origin.
for spine in ['left', 'bottom']:  #for spine in ['left', 'bottom']:# Make the coordinateaxis in the lower left corner pass the origin.
    ax.spines[spine].set_position('zero')
#Draw a grid:
ax.grid(alpha=0.4)
#Set the coordinate axis ranges.
xmin, xmax =-3, 3
ymin, ymax =-3, 3
ax.set(xlim=(xmin, xmax), ylim=(ymin, ymax))
'''
#
Draw an eigenvector. Annotation is to use an arrow that points to the content to
be explained and add a description. In the following code, s indicates the input, xy
indicates the arrow direction, xytext indicates the text location, and arrowprops
uses arr owstyle to indicate the arrow style or type.'''



for v in evecs:
    ax.annotate("Eigene", xy=v, xytext=(0, 0),arrowprops=dict(facecolor='blue', shrink=0, alpha=0.6,width=0.5))

#Draw the eigenspace:
x = np.linspace(xmin, xmax, 3)# Return evenly spaced numbers over a specified interval.
for v in evecs:
    a = v[1] / v[0]  # Unit vector in the eigenvector direction.
    ax.plot(x, a * x, linestyle='--', lw=0.4)  # The lw parameter indicates the line thickness.
plt.show()
#This section describes how to obtain the determinant of a matrix.
E= [[1, 2,3],
    [4, 5,6],
    [7, 8,9]]
print(np.linalg.det(E))
