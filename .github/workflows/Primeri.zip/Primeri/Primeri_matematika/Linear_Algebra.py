import numpy as np
import scipy as sp
'''
There is no reshape operation in mathematics, but it is a very common operation
in the NumPy operation library. The reshape operation is used to change the
dimension number of a tensor and size of e ach dimension. For example, a 10x10
image is directly saved as a sequence containing 100 elements. After inputting the
image, it can be transformed from 10x10 to 1x100 through the reshape operation.
The following is an example:
Input:
Generate a vector that contains integers from 0 to 11.'''
x = np.arange(12)
print(x)
#View the array size.
a=x.shape
print(a)
#Convert x into a two dimensional matrix, where the first dimension of the matrix is 1.
x = x.reshape(1,12)
print(x)
#Convert x to a 3x4 matrix.
x = x.reshape(3,4)
print(x)
'''
The transpose of vectors and matrices is to switch the row and column indices. For
the transpose of tensors of three dimensions and above, you need to specify the
transpose dimension.'''
#Generate a 3x4 matrix and transpose the matrix.
A = np.arange(12).reshape(3,4)
print(A)
B=A.T
print(B)
#To multiply the matrix A and matrix B, the column quantity of A must be equal to the row quantity of B.
A = np.arange(6).reshape(3,2)
B = np.arange(6).reshape(2,3)
print(A)
print(B)
#Matrix multiplication:
C=np.matmul(A,B)
print(C)
'''
Element operations are operations on matrices of the same shape. For example,
element operations include the addition, subtraction, division, and multiplication
operations on elements with the same position in two matrices.'''
#Create matrix A:
A = np.arange(6).reshape(3,2)
#Matrix multiplication:
print(A*A)
#Matrix addition:
print(A + A)
#Inverse matrix implementation is applicable only to square matrices.
A = np.arange(4).reshape(2,2)
print(A)
#Inverse matrix:
np.linalg.inv(A)
