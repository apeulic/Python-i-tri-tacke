import math
import numpy as np

'''
The ceil(x) function obtains the minimum integer greater than or equal to x. If x is
an integer, the returned value is x.
'''
a=math.ceil(4.01)
b=math.ceil(4.99)
print('a:',a,'b:',b)
'''
The floor(x) function obtains the maximum integer less than or equal to x. If x is
an integer, the returned value is x.
'''
a=math.floor(4.1)
b=math.floor(4.999)
print('a:',a,'b:',b)
'''
The degrees(x) function converts x from a radian to an angle.
'''
a=math.degrees(math.pi/4)
b=math.degrees(math.pi)
print('a:',a,'b:',b)
'''
The exp(x) function returns math.e,
that is, 2.71828 to the power of x.
'''
math.exp(1)
'''
The fabs(x) function returns the absolute value of x.
'''
math.fabs(0.003)
'''
The factorial(x) function returns the
factorial of x.
'''
math.factorial(3)
'''
The fsum(iterable) function summarizes each element in the iterator.'''
math.fsum([1,2,3,4])
'''
The fmod(x, y) function obtains the remainder of x/y. Th
e value is a floating point
number.'''
math.fmod(20,3)
'''
The log([x, base]) function returns the natural logarithm of x. By default, e is the
base number. If the base parameter is specified , the logarithm of x is returned
based on the given base. The calculation formula is log(x)/log(base).'''
math.log(10)
'''
The sqrt(x) function returns the square root of x.'''
math.sqrt(100)
'''
pi is a numerica
l constant, indicating the circular constant.'''
math.pi
'''
The pow(x, y) function returns the x to the power of y, that is,
𝑥𝑦'''
math.pow(3,4)
