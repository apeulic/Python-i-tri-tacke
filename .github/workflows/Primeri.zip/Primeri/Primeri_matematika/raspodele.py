from scipy.stats import binom, norm, beta, expon
import numpy as np
import matplotlib.pyplot as plt
'''
# The
n and p parameters indicate the su ccess times and probability in the binomial formula,
respectively, and size indicates the number of sampling times.
binom_sim
'''
binom_sim = binom.rvs(n=10, p=0.3, size=10000)
print('Data:',binom_sim)
print('Mean: %g' % np.mean(binom_sim))
print('SD: %g' %
np.std(binom_sim, ddof=1))
'''
# Generate a histogram.
The bins parameter indicates the number of bars in total. By default,
the sum of the percentages of all bars is 1.
'''
plt.hist(binom_sim, bins=10)
plt.xlabel(('x'))
plt.ylabel('density')
plt.show()

#Poisson Distribution Implementation
# Generate 10,000 numbers that comply with the Poisson distribution where the value of lambda is 2.
X= np.random.poisson(lam=2, size=10000)
a = plt.hist(X, bins=15, range=[0, 15])
# Generate grids.
plt.grid()
plt.show()
#Normal Distribution
mu = 0
sigma = 1
#Return evenly spaced values within a given interval (start, stop, step).
x = np.arange(-5, 5, 0.1)
# Generate normal distribution that complies with mu and sigma
y = norm.pdf(x, mu, sigma)
plt.plot(x, y)
plt.xlabel('x')
plt.ylabel('density')
plt.show()
