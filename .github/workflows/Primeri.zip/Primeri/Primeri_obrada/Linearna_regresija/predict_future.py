
from scipy import stats
from sklearn import linear_model
# Pandas has DataFrames and Series, very useful things
import pandas as pd
# numpy has lots of useful things in it
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
plt.style.use("seaborn-whitegrid")
from IPython.display import display
import numpy


#df = pandas.read_csv("Air_kerma.csv")
excel_file = "air_kerma_predi.xlsx"
#dtf = pd.read_excel(r"dodatni podaci.xlsx",sheet_name='ASTMA')
df = pd.read_excel(r"air_kerma_predi.xlsx")
#print(df.head())
# set the max columns to none
pd.set_option('display.max_columns', None)
display(df)

x = df['DAP_Gycm2']
y = df['Air_Kerma']

slope, intercept, r, p, std_err = stats.linregress(x, y)

def myfunc(x):
  return slope * x + intercept

kerma = myfunc(x)
kerma.to_csv('predicted.csv', index=False)

print(kerma)

