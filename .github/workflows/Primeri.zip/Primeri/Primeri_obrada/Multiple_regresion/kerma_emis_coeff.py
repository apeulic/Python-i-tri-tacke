
from sklearn import linear_model
# Pandas has DataFrames and Series, very useful things
import pandas as pd
# numpy has lots of useful things in it
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
plt.style.use("seaborn-whitegrid")
from IPython.display import display
import numpy


#df = pandas.read_csv("Air_kerma.csv")
excel_file = "multi_reg.xlsx"
#dtf = pd.read_excel(r"dodatni podaci.xlsx",sheet_name='ASTMA')
df = pd.read_excel(r"multi_reg.xlsx")
#print(df.head())
# set the max columns to none
pd.set_option('display.max_columns', None)
display(df)


X = df[['Time', 'Age','DAP_Gycm2']]
#X = df[['Time', 'DAP_Gycm2']]
y = df['Air_Kerma']
##############################################end polinom
regr = linear_model.LinearRegression()
regr.fit(X, y)

print(regr.coef_)

import pandas
from sklearn import linear_model

excel_file = "multi_reg.xlsx"
#dtf = pd.read_excel(r"dodatni podaci.xlsx",sheet_name='ASTMA')
df = pd.read_excel(r"multi_reg.xlsx")
#print(df.head())
# set the max columns to none
pd.set_option('display.max_columns', None)
display(df)

X = df[['Time', 'DAP_Gycm2']]
y = df['Air_Kerma']



regr = linear_model.LinearRegression()
regr.fit(X, y)

predicted_kerma = regr.predict(X)
#print('Za Time 2.5, Age 60, DAP_Gycm2 75.026')

print('predicted_Air_Kerma:', predicted_kerma)

# save numpy array as csv file
from numpy import asarray
from numpy import savetxt
#predicted_kerma.to_csv('predicted_kerma.csv', index=False)
savetxt('predicted_multi_bez_age.csv', predicted_kerma, delimiter=',')
