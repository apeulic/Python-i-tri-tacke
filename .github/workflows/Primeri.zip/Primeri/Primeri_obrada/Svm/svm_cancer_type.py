#Import scikit-learn dataset library
from sklearn import datasets

import pandas as pd
'''
Loading Data
Let's first load the required dataset you will use
'''
#Load dataset
cancer = datasets.load_breast_cancer()
#cancer=pd.read_csv('Steel_Plates_Faults.csv')

'''
Exploring Data
After you have loaded the dataset, you might want to know a little bit more about it.
You can check feature and target names.
'''
# print the names of the 13 features
print("Features: ", cancer.feature_names)
#print("Features: ", cancer.Minimum_of_Luminosity)

# print the label type of cancer('malignant' 'benign')
print("Labels: ", cancer.target)

# Let's explore it for a bit more. You can also check the shape of the dataset using shape
# print data(feature)shape
print(cancer.data.shape)
#print(cancer.Sum_of_Luminosity.shape)
# print the cancer data features (top 5 records)
print(cancer.data[0:5])
#print(cancer.Sum_of_Luminosity[0:5])
#Let's take a look at the target set.
# print the cancer labels (0:malignant, 1:benign)
print(cancer.target)
#print(cancer.Fault)

'''
Splitting Data
To understand model performance, dividing the dataset into a training set and a test set is a good strategy.
Split the dataset by using the function train_test_split(). you need to pass 3 parameters features, target, 
and test_set size. 
Additionally, you can use random_state to select records randomly.
'''
# Import train_test_split function
from sklearn.model_selection import train_test_split

# Split dataset into training set and test set
X_train, X_test, y_train, y_test = train_test_split(cancer.data, cancer.target, test_size=0.3,random_state=109) # 70% training and 30% test
#X_train, X_test, y_train, y_test = train_test_split(cancer.Sum_of_Luminosity, cancer.Fault, test_size=0.3,random_state=109) # 70% training and 30% test
'''
Generating Model

Let's build support vector machine model. 
First, import the SVM module and create support vector classifier object by passing argument 
kernel as the linear kernel in SVC() function.
Then, fit your model on train set using fit() and perform prediction on the test set using predict().
'''
#Import svm model
from sklearn import svm

#Create a svm Classifier
clf = svm.SVC(kernel='linear') # Linear Kernel

#Train the model using the training sets
clf.fit(X_train, y_train)

#Predict the response for test dataset
y_pred = clf.predict(X_test)

'''
Evaluating the Model

Let's estimate how accurately the classifier or model can predict the breast cancer of patients.

Accuracy can be computed by comparing actual test set values and predicted values.
'''
#Import scikit-learn metrics module for accuracy calculation
from sklearn import metrics

# Model Accuracy: how often is the classifier correct?
print("Accuracy:",metrics.accuracy_score(y_test, y_pred))

'''
Well, you got a classification rate of 96.49%, considered as very good accuracy.

For further evaluation, you can also check precision and recall of model.
'''

# Model Precision: what percentage of positive tuples are labeled as such?
print("Precision:",metrics.precision_score(y_test, y_pred))

# Model Recall: what percentage of positive tuples are labelled as such?
print("Recall:",metrics.recall_score(y_test, y_pred))
