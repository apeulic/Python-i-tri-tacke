from PIL import Image
from PIL import ImageOps

im = Image.open("Reka.jpg")
print(im.format, im.size, im.mode)
im.show()

#area = (40, 40, 80, 80)
#cropped_img = im.crop(area)
#cropped_img.show()
border = (80, 120, 80, 120) # left, up, right, bottom
cropped_img_2 = ImageOps.crop(im, border)
cropped_img_2.show()
cropped_img_2 = cropped_img_2.resize((320,320))
cropped_img_2.show()

