import cv2
 
img = cv2.imread(r'C:\AP\projekti\Python\Knjiga\obrada_slike\Primeri_slika\rekovac.jpg')
cv2.imshow("Rekovac",img)
cv2.waitKey(0)
img_resized = cv2.resize(img, (300, 300))
cv2.imshow("Promena dimenzija ", img_resized);
cv2.waitKey(0)
(vrsta, colona, depth) = img.shape
colona_resized = 400; # fiksiramo širinu nove slike
vrsta_resized = int(colona_resized * vrsta / colona)
img_resized = cv2.resize(img, (colona_resized, vrsta_resized))
cv2.imshow("Smanjena zadrzan odnos", img_resized);
cv2.waitKey(0)
# Crtanje i pisanje po slici
out_img = img_resized.copy()
top_left_x = 10 # x koordinata - odgovara koloni matrice
top_left_y = 10 # y koordinata - odgovara redu matrice
bottom_right_x = img.shape[1] - 10 # citava sirina
bottom_right_y = top_left_y + 30
rect_color = (0, 255, 0) # BGR
cv2.rectangle(out_img, (top_left_x, top_left_y), (bottom_right_x, bottom_right_y), rect_color, 1)
cv2.imshow("Nacrtan zeleni pravougaonik", out_img);
#pisanje teksta u pravougaonik
cv2.waitKey(0)
font_face = cv2.FONT_HERSHEY_SIMPLEX
font_scale = 0.6
font_color = (0, 0, 255) # BGR
font_thick = 1 # integer
bottom_left_x = top_left_x + 10; # x - odgovara koloni matrice
bottom_left_y = bottom_right_y - 10; # y - odgovara redu matrice
cv2.putText(out_img, "OVO JE TEKST", (bottom_left_x, bottom_left_y), font_face, font_scale, font_color, font_thick)
cv2.imshow("Rezultat", out_img)
cv2.waitKey(0)

