import cv2
import numpy as np

print(cv2.__version__)

img = cv2.imread(r'C:\AP\projekti\Python\Knjiga\obrada_slike\Primeri_slika\Reka.jpg')          # ucitavanje slike u memoriju
if img is not None:
    print('variable is not None')
    print(img.shape)
else:
    print('variable is None')

(rows, cols, channels) = img.shape # dimenzije slike kao matrice
print("Dimenzije slike u boji (visina, sirina, dubina):", rows, cols, channels)
print("Tip promenljive piksela:", img.dtype)
cv2.imshow("Slika", img) # prikaz slike na ekran
cv2.waitKey(0)

# Pristup pikselu na poziciji [10, 60]
(b, g, r) =  img[10, 60]
print("Komponente boje piksela (blue, green, red):", b, g, r);
# Moze i posebno ocitavanje svakog kanala boje
b = img[10, 60, 0]              # B komponenta boje piksela
print("Komponentа blue:", b);
g = img[10, 60, 1]              # G komponenta boje piksela
print("Komponentа green:", g);
r = img[10, 60, 2]              # R komponenta boje piksela
print("Komponentа red:", r);

# Brza varijanta ~2x
b = img.item(10, 60, 0) # B komponenta boje piksela
g = img.item(10, 60, 1) # G komponenta boje piksela
r = img.item(10, 60, 2) # R komponenta boje piksela
print("Komponente boje piksela (blue, green, red) - varijanta 2:", b, g, r);

# Postavljanje boje piksel na poziciji [100, 5]
img[10, 60] = (0, 0, 255) # Boji piksel u црвено
# Drugi nacin (brze)
img.itemset((10, 60, 0),0)
img.itemset((10, 60, 1) ,0)
img.itemset((10, 60, 2) ,255)
#izdvojimo region tj. podmatricu koja je ograničena redovima od 100:190 i kolonama od 40:440
roi = img[100:190, 40:340]
cv2.imshow("Izdvojen ROI", roi)
cv2.waitKey(0)

B = img[:, :, 0] # B kanal boje kao podmatrica
G = img[:, :, 1] # G kanal boje kao podmatrica
R = img[:, :, 2] # R kanal boje kao podmatrica

# Y = 0.299*R + 0.587*G + 0.114*B
img_gray = np.uint8( 0.299*R + 0.587*G + 0.114*B )
cv2.imshow("Siva slika (grayscale, monohromatska, 8-bitna)", img_gray)
cv2.waitKey(0)
# isto poziv cv2.color
imgGry = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
cv2.imshow("Siva slika poziv cv2.cvtColor )", imgGry)
cv2.waitKey(0)

