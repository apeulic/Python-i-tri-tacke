import cv2

img = cv2.imread('Reka.jpg')          # ucitavanje slike u memoriju
if img is not None:
    print('variable is not None')
    print(img.shape)
else:
    print('variable is None')

(rows, cols, channels) = img.shape # dimenzije slike kao matrice
print("Dimenzije slike u boji (visina, sirina, dubina):", rows, cols, channels)
print("Tip promenljive piksela:", img.dtype)
cv2.imshow("Slika", img) # prikaz slike na ekran
cv2.waitKey(0)