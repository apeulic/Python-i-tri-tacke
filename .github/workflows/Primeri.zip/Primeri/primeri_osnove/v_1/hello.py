print('zdravo svete')
print("zdravo svete")
# trostruki navodni omogućavaju prosirivnje na više redova
print("""zdravo
svete""")
