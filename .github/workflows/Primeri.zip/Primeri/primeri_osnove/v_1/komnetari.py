# Komentari su veoma važni prilikom pisanja programa.
# Oni objašnjavaju kodove  kako bi bolje razumeli program

'''
U Python-u se koristi heš (#) simbol za započinjanje pisanja komentara.
Python Interpreter ignoriše komentare tokom izvršavanja.
# za jedan red
Moguce je komentarisati redova. Jedan od načina je da koristite simbol heš(#)
na početku svakog reda.
Drugi način je da se koriste trostruki navodnici,  '''


print("hello world") #ovo je komentar


