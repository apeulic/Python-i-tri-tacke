# Packages and modules
'''
Python ima pakete i module. Modul je datoteka koja sadrži Python kod.
Paket je kao direktorijum koji sadrži podpakete i module.
Biblioteka sadrži više modula.
Kako  program postaje sve veći sa mnogo modula,
slični moduli se stavljaju u jedan paket i različite module u različite pakete.
Ovo čini projekat (program) laksim za upravljanje i konceptualno jasnim.
Da bi se koristili pakete i moduli u Python-u koristi se:
import
from ... import ...
'''
import os  # import os module
os.getcwd() # get the current working directory
print(os.getcwd())

from os import getcwd # import getcwd method from os module
getcwd()              # get the current working directory
print(getcwd())

'''
Ako je ime paketa previše složeno za pozivanje, može mu se dati pseudonim.
'''
import platform
platform.platform()
print(platform.platform())

import platform as pf
pf.platform()
print(pf.platform())
