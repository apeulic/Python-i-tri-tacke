t=(1,[1,2],"python")
print(t)
print(type(t))
