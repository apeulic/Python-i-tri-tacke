x1 = int(input("Unesi prvi broj: "))
x2 = int(input("Unesi drugi broj: "))
x3 = int(input("Unesi treci broj: "))
c = (x1+x2+x3)/3
print('Srednja vr. je',c)


