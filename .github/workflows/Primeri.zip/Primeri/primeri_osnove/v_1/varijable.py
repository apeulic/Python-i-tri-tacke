# varijable
'''
Promenljive su kontejneri za čuvanje vrednosti podataka.
Promenljiva je imenovana lokacija koja se koristi za skladištenje podataka u
memoriji.
Deklarisanje i dodeljivanje vrednosti promenljivoj
'''
a=2
print('Vrednost za a je:  ', a)


#vrednost varijable moze da se promeni
a=2
print(a)

# nazivi i kljucne reci
'''
Imena promenljivih treba da imaju kombinaciju slova mala (a do z)
ili velika  (A do Z) ili cifara (0 do 9) ili donju crtu (_).
'''
aA9_=1
# imena treba da imaju smisla
wasd=100
price=100
# za promenljivu koja ima dve reci, koristi se underscore
number_of_cats=6
#!!!! naziv promenljive ne sme da pocne brojem
#1a=1 # incorrect variable names

'''
Ključne reči su rezervisane reči u Python-u.
Ne mogu se koristiti kao obični identifikatori i moraju biti tačno napisani.
U Pithon-u 3.7 postoji 35 ključnih reči.
'''
#def=1 # when a variable name is a keyword

import keyword
keyword.kwlist
print(keyword.kwlist)

help("keywords")

# zamena vrednosti promenljivih
print('zamena vrednosti promenljivih')
a=1
b=2
print(a)
print(b)
a,b=b,a
print(a)
print(b)

'''
#Redosled izvrsavanja
# Odozgo na dole
x=0
print(x+y)
y=1
'''
x=2
y=1
z=x+y
print(z)



