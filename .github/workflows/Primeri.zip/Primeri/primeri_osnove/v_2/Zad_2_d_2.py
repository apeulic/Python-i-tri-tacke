string1 = input("Unesi recenicu: ")
a = string1.count('a')
e = string1.count('e')
i = string1.count('i')
razmak = string1.count(' ')
tacke = string1.count('.')
ukupno = len(string1) - a -e - i - razmak + tacke*2
print (ukupno)
