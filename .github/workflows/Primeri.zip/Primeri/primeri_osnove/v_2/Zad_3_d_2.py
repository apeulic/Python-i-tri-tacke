prva = input("Unesi prvu rec: ")
druga = input("Unesi drugu rec: ")

string1 = input("Unesi string 1: ")
string2 = input("Unesi string 2: ")
string3 = input("Unesi string 3: ")

prvo = string1.find(prva)
drugo = string1.find(druga)
s1 = string1[prvo:drugo]
s1 = s1.lower()
prvi_broj = float(s1.count('a'))

prvo = string2.find(prva)
drugo = string2.find(druga)
s2 = string2[prvo:drugo]
s2 = s2.lower()
pom = s2.count('a')
drugi_broj = float(len(s2) - pom)

prvo = string3.find(prva)
drugo = string3.find(druga)
s3 = string1[prvo:drugo]
treci_broj = float(len(s3))

print ("Aritmetička sredina je %.2f" %((prvi_broj + drugi_broj + treci_broj)/3))
