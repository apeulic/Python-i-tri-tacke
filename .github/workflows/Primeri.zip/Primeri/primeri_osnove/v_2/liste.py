'''
# Елементе листе генеришемо набрајањем у угластим заградама
# и одвајамо их зарезом.
zivotinje=['pas','macka','mis','majmun','slon']
print (zivotinje)


# Листу можемо генерисати и на следећи начин:
lista=list(range(1,10))
print (lista)


lista=list(range(1,10,2))
print (lista)



# Приступање елементима листе, Индексирање

lista=[10, 9, 8, 7,-1,-2,-3]
print (lista[3])


#последњи елемент листе
lista=[10, 9, 8, 7,-1,-2,-3]
print (lista[-1])


print ( lista[7] )
'''

'''
#Промена вредности елемената листе
lista = [2, 4, 6, 8]
print ( lista )
lista[2]=0
print ( lista )
'''


'''
#Спајање листи
A = [1,2,3,4,5]
B = [6,7,8,9]
C = A + B

# B ='Jovana'
print (C)
'''

'''
A=[1,2,3,4,5]
B=["Jovana"]
C=A+B
print (C)
'''

'''
#len - враћа дужину листе
lista=["jedan" , 2,3,4,5,[-2,-4,-5]]
print(lista)
print (len(lista))
'''
'''
#број елемената у листи која је унутар листе
lista=["jedan" , 2,3,4,5,[-2,-4,-5]]
print ( len(lista[5]))
'''
'''
# колико карактера има неки String
lista=["jedan" , 2,3,4,5,[-2,-4,-5]]
print ( len(lista[0]))
'''

'''
namirnice = ['hleb','jaja','mleko','jogurt','piletina','sir','salata']
print ( len(namirnice) )
'''

'''
# primer Аppend
lista = [1,2,3]
lista.append([4,5])
print ( lista )
print ( len(lista))
# primer extend
lista = [1,2,3]
lista.extend([4,5])
print ( lista )
print ( len(lista))
'''


'''
# insert - додаје жељени елемент на дату позицију
A = [1,2,3,4,5]
A.insert(2,0)
print ( A )
'''
'''
#max i min - Проналазе максимум и минимум у листи
A=[1,13,-2,6,101,28,44,17,-27]
print ( min(A) )
print ( max(A) )
'''
'''
#count – враћа број понављања неког елемента у листи
A=[2,3,4,1,7,2,3,1,1,0,9,5]
print ( A.count(2) )
'''
'''
#del i pop – служе за брисање елемената из листе
A=[1,2,3,4,5,6,7,8,9]
print ( A )
del(A[3])
print ( A )
A.pop(1)
print ( A )
A.pop()
print ( A )
'''
'''
#remove – ова функција уклања прво појављивање прослеђеног аргумента
A=['jedan','dva','sedam','dva']
print ( A )
A.remove('dva');
print ( A )
'''
'''
#sort – ова функција сортира елементе листе у неопадајућем поретку
A=[2,6,1,9,3,5,4]
print ( A )
A.sort()
print ( A )
A.reverse()
print ( A )
'''
'''
#Исецање елемената листе
A=[ 1 , 2 , 3 , 4 , 5 , 6 , 7, 8, 9 ]
print ( A )
print ( A[4:-1] )
A=[ 1 , 2 , 3 , 4 , 5 , 6 , 7, 8, 9 ]
print ( A[4:-1:2] )
'''


#листе парова
lista=[(1,2),(3,4),(5,6)]
print ( lista )

lista=[(1,2,3),(4,5,6),(7,8,9)]

print ( lista )








