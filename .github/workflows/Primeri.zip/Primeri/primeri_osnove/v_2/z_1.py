lista=[12,33,28,13,10,6,88,4,59,3]
print ( lista )
lista[-1]=101
lista[4]=0
lista[-2]=-1
print ( lista )
