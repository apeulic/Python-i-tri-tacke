lista = [4,7,11,28,17,8,33,54,41,23,29,37,45,36,13]
print(lista)
print ( lista[0:14:3] )
