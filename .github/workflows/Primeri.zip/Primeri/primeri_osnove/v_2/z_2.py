namirnice = ["hleb","jaja","mleko","jogurt","piletina","sir","salata"]
print ( len(namirnice) )
