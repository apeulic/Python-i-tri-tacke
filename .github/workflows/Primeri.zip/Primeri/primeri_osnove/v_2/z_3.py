z=["slon","konj","kit"]
z.append(["svinja","kokoska"])
z.extend(["lav"])
print ( z )
print ( z[3] )
