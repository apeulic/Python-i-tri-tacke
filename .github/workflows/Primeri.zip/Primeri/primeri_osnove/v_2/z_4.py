imena = ["Darko","Marko","Ana","Sanja"]
imena.insert(0,1)
imena.insert(2,2)
imena.insert(4,3)
imena.insert(6,4)
print ( imena )
