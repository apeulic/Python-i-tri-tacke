imena = ["Darko","Marko","Ana","Sanja"]
print ( min(imena) )
print ( max(imena) )
