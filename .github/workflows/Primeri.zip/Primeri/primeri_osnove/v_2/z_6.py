imena = ["Darko","marko","Ana","Sanja",'Jovana','Ana']
print ( imena.count('Ana') )
