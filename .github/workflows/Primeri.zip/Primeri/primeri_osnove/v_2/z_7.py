sport=['hokej','tenis','kosarka','odbojka','fudbal']
print ( sport )
sport.pop()
print ( sport )
sport.pop(0)
print ( sport )
