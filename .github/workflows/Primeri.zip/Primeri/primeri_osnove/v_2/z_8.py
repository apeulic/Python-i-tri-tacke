A=['Novi Sad', 'Kragujevac','Beograd','Nis','Cacak']
A.remove("Beograd")
print ( A )
