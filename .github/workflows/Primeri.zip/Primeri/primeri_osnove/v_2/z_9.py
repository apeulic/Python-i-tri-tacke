A=[10, 23, 6, 17, 12, 28, 13,30,9,21]
A.sort()
print ( A )
A.reverse()
print ( A )
