n = int(input("unesite broj: "))
niz=[]
for i in range(n):
    broj= int(input("broj:"))
    niz.append(broj)

for br in range(0,len(niz)):
    if niz[br]%5 == 0:
        print ("deljiv je sa 5")
    elif niz[br]%7 == 0:
        print ("deljiv je sa 7")
    else:
        print ("nije deljiv ni sa jednim od ovih brojeva")
