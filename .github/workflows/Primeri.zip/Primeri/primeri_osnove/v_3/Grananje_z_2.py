broj_cigli = int(input('unesite broj cigli: '))
broj_dzakova_cementa = int(input('unesite broj dzakova cementa: '))
if (broj_cigli > 10000 and broj_cigli < 15000 and broj_dzakova_cementa > 1500 ):
    preostalo = broj_cigli - 10000 + broj_dzakova_cementa - 1500
    print ('napravio sam prizemlje ali nemam dovoljno i za potkrovlje')
    print (' materijala je preostalo: ' + str(preostalo))
elif (broj_cigli >= 15000 and broj_dzakova_cementa > 2000 ):
    preostalo = broj_cigli - 15000 + broj_dzakova_cementa - 2000
    print ('napravio sam prizemlje i potkrovlje')
    print (' materijala je preostalo: ' + str(preostalo))
else:
    print ('nema dovoljan broj dzakova cementa i cigli za sprat')
