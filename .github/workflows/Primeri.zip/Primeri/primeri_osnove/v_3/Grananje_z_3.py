n= int(input ("uneti broj elemenata niza : "))
cene = []
for i in range(n):
    broj = int(input("uneti cenu:"))
    cene.append(broj)
    
if (sum(cene) >= 10000 and len(cene) < 10):
    popust = sum(cene)-sum(cene) * 20 / 100
    print (popust)
elif (len(cene) >= 10 and sum(cene) < 10000):
    popust = sum(cene)-sum(cene) * 10 / 100
    print (popust)
elif (sum(cene) >= 10000 and len(cene) >= 10):
    popust = sum(cene)- sum(cene) * 30 / 100
    print (popust)
else:
    print (sum(cene))
