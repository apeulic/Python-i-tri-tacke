mesec = input('uneti mesec recima: ')
godina = int(input('koja je godina: '))
if (mesec == 'januar' or mesec == 'mart' or mesec=='maj' or mesec == 'jul' or mesec == 'avgust' or mesec == 'oktobar' or mesec=='decembar' or mesec=='septembar'):
    print (31)
elif ((godina%4 == 0) and (mesec == 'februar')):
    print (29)
elif ((godina%4) and (mesec == 'februar')):
    print (28)
