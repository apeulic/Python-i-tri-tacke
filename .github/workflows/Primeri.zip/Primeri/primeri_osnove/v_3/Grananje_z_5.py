n = int(input ('unesite broj: '))
spisak_po_kg=[]
for i in range(n):
    broj = int(input('unesite tezine:'))
    spisak_po_kg.append(broj)
for v in range(0,len(spisak_po_kg)):
    if spisak_po_kg[v] < 100 and spisak_po_kg[v] > 60:
        print(v)
kg_ispod_100 = [v for v in spisak_po_kg if v < 100 and v > 60]
print(kg_ispod_100)
