recenica = input('unesi recenicu: ')
if recenica.count('a') > 5 :
    print ('ima vise od 5 pojavljivanja slova a: ' + str(recenica.count('a')))
elif recenica.count('b') > 5 :
    print ('ima vise od 5 pojavljivanja slova b: ' + str(recenica.count('b')))
else:
    print ('nema slova a i b ciji je zbir pojavljivanja veci od 5')
