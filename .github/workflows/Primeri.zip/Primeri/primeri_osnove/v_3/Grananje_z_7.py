ucenici = [("Pera", 78.5), ("Lenka", 56.6), ("Jovana", 21.45),("Milena", 30), ("Ognjen", 66.5), ("Milos", 95.45)]
for (ucenik, prosek) in ucenici:
    if prosek >= 50 :
        print ((ucenik) + ' ima pravo na stipendiju')
else:
    print ((ucenik) + ' nema pravo na stipendiju')
