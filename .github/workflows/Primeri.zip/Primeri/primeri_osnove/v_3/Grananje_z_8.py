n = int(input('unesi broj imena: '))
niz=[]
for i in range(n):
    ime =input('unesite ime: ')
    niz.append(ime)
for i in range(0,len(niz)):
    if len(niz[i]) > 4:
        print (str(niz[i]) + ' ima vise od 4 slova')
    elif len(niz[i]) < 4:
        print (str(niz[i]) + ' ima manje od 4 slova')
else:
    print (str(niz[i]) + ' ima 4 slova')
