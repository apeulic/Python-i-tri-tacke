print ("Igra pogađanja brojeva")
print ("Za prekid igre unesite 0")
pogodi=17
while True:
    broj=int(input("Unesite broj: "))
    if broj==pogodi:
        print ("Pogodili ste zadani broj čestitamo!")
        broj=0
        break
    elif broj==0:
        break
    elif broj > pogodi:
        print ("Broj je manji od zadanog, pokušajte ponovo")
    elif broj < pogodi:
        print ("Broj je veci od zadanog, pokušajte ponovo")
