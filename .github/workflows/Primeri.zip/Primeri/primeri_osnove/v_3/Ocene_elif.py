poeni =int(input("Uneiste broj poena:"))
if poeni < 51:
    ocena = 5
    print("Pali ste ispit!\n Ocena je 5")
elif poeni < 61:
    ocena = 6
    print("Polozili ste ispit!\n Ocena je 6")
elif poeni < 71:
     ocena = 7
     print("Polozili ste ispit!\n Ocena je 7")
elif poeni < 81:
    ocena = 8
    print("Polozili ste ispit!\n Ocena je 8")
elif poeni < 91:
    ocena = 9
    print("Polozili ste ispit!\n Ocena je 9")
else:
    ocena = 10
    print("Polozili ste ispit!\n Ocena je 10")

print("Kraj programa")


