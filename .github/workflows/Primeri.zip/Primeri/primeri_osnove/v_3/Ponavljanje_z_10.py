#Написати програм који симулира валидацију шифре за унети string.
# Најмање једно слово од [a-z] и једно слово од [A-Z].
# Најмање један број у распону [0-9].
# Најмање један од специјалних карактера [$#@].
#Минимална дужина 6
#Максимална дужина 16
#RegEx can be used to check if a string contains the specified search pattern.
import re
p= input("Unesite sifru")
x = True
while x:
    if (len(p)<6 or len(p)>12):
        break
    elif not re.search("[a-z]",p):
        break
    elif not re.search("[0-9]",p):
        break
    elif not re.search("[A-Z]",p):
        break
    elif not re.search("[$#@]",p):
        break
    elif re.search("\s",p):
        break
    else:
        print("Dobra sifra")
        x=False
        break
if x:
    print("Losa sifra")

        
