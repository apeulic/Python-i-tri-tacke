# Написати програм који учитава имена и исиписује, све док се не унесе 0
#(Решење наћи коришћењем while петље и наредбе break )
while True:
    ime = input("Uneti string")
    print (ime)
    if(ime=='0'):
        break
    
