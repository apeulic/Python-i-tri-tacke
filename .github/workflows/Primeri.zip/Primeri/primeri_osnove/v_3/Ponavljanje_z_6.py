# Написати програм који учитава i штампа бројеве све док се не унесе број 9.
# Ако је унет број дељив са 3 прескочити његово штампање.
broj =0
while broj!=9:
    broj = int(input("Uneti broj"))
    if(broj%3==0):
        continue
    print (broj)
