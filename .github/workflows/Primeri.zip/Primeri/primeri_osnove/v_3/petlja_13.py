visine = [162, 168, 175, 181, 159, 172]
for v in visine:
    if v < 170:
        print(v)
