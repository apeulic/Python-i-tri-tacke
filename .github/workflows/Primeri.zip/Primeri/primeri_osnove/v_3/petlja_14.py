visine = [162, 168, 175, 181, 159, 172]
visine_ispod_170 = [v for v in visine if v < 170]
print(visine_ispod_170)
