ucenici = [("Pera", "IV/3"), ("Lenka", "VII/5"), ("Jovana", "VI/2"),
           ("Milena", "IV/3"), ("Ognjen", "VI/2")]
for (ucenik, odeljenje) in ucenici:
    if odeljenje == "VI/2":
        print(ucenik)
