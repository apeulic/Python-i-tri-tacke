odeljenje = "VI/2"
ucenici = [("Pera", "IV/3"), ("Lenka", "VII/5"), ("Jovana", "VI/2"),
           ("Milena", "IV/3"), ("Ognjen", "VI/2")]
iz_odeljenja = [ucenik[0] for ucenik in ucenici if ucenik[1] == odeljenje]
print(iz_odeljenja)
