predmeti=[]
while True:
    predmet=input("unesi predmet")
    predmeti.append(predmet)
    if (predmet=="informatika"):
        break
    print(predmeti)
