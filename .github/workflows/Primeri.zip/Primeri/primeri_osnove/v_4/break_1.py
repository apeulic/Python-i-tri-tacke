for broj in range(1,10):
    if broj== 3:
        continue
print (broj)