x = int(input("Unesite broj ocena"))
broj_ocena=2
while x <= broj_ocena:
    ocena = int(input("Unesite ocenu: "))
    broj_ocena = broj_ocena + 1
    if ocena < 5 or ocena > 10:
        print("Dozvoljeno je unositi samo ocene od 5 do 10, prekid petlje")
        break

