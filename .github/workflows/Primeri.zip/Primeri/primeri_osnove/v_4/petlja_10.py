naucnici = [("Nils", "Bor"), ("Čarls", "Darvin"), ("Isak", "Njutn"), ("Marija", "Kiri")]
for i in range(len(naucnici)):
    naucnik = naucnici[i]
    print(naucnik[0], naucnik[1])
