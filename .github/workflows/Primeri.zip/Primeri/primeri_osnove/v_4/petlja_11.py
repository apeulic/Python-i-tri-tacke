naucnici = [("Nils", "Bor"), ("Čarls", "Darvin"), ("Isak", "Njutn"), ("Marija", "Kiri")]
for (ime, prezime) in naucnici:
    print(ime, prezime)
