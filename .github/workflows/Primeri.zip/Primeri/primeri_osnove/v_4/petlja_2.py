n = int(input("Unesi broj učenika: ")) # učitaj broj učenika n
for i in range(n): # ponovi n puta:
    ime = input("Kako se zoveš: ") # unesi ime učenika
    print("Zdravo, ti se zoveš:", ime) # pozdravi učenika
