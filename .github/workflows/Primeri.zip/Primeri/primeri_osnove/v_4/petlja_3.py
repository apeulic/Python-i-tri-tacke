a = int(input("Unesi a: "))
b = int(input("Unesi b: ")) 
for i in range(a,b+1):
    print(i) # Štampa broj
