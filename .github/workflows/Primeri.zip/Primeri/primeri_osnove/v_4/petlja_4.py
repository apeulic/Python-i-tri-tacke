for i in range(5,100,5):
    print(i) # Štampa broj
