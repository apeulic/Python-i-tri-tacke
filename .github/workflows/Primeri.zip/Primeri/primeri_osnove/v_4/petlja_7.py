ljubimci = ['pas','macka','papagaj','zmija']
print(ljubimci)
for pera in ljubimci:
    print('Setam ' + pera)

