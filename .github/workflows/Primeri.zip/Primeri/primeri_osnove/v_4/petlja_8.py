ljubimci = ['pas','macka','papagaj','zmija']
print(ljubimci)
for i in range(len(ljubimci)):
    print('Setam ' + ljubimci [i])

