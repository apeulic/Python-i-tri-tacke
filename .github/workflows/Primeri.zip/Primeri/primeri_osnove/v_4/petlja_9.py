naucnici = [("Nils", "Bor"), ("Čarls", "Darvin"), ("Isak", "Njutn"), ("Marija", "Kiri")]
for naucnik in naucnici:
    print(naucnik[0], naucnik[1])

