for broj in range(20,200,3):
    print(broj)

