for i in range(1,10):
    if i== 3:
        break
print (i)
