broj_ocena = int(input("Unesite broj ocena"))
niz = [] #Inicijalizacija liste
x=1
while x<=broj_ocena:
    ocena= int(input("Unesite ocenu: "))
    x=x+1
    if ocena<1 or ocena>5:
        print ("Dozvoljeno je unositi samo ocene od 1 do 5, prekid petlje")
        break
    niz.append(ocena) #Dodavanje novog elementa listi
    
    if(len(niz)==broj_ocena): #Proveravamo da li su unete sve ocene
        print ("unete su ocene: "+str(niz))
