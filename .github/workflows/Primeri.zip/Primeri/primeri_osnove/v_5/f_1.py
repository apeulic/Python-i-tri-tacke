def oduzmi(): # funkcija
    print (100-50) # telo funkcije
oduzmi() # poziv funkcije
