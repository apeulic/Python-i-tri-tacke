def izracunaj_kvadrat(x):
    print (x*x)

izracunaj_kvadrat(3) #pozivamo funkciju, koja daje izlaz 9
izracunaj_kvadrat(8) #pozivamo funkciju, koja daje izlaz 64
