def saberi(x,y):
    print (x+y)
#pozivamo funkcije sa dva argumenta
saberi(10,15)
saberi(3,15) 
