def stampaj_poruku():
    print ("Ucimo programski jezik Pajton")
stampaj_poruku() #pozivamo funkciju bez argumenata
