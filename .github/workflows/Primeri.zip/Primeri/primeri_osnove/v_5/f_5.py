def stampaj_duzinu(st):
    print (len(st))
unos=input("uneti string")
stampaj_duzinu(unos) #pozivamo funkciju stampaj_duzinu
