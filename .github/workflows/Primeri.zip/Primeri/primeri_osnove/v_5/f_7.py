import math

def povrsina_kruga():
    r=float(input("Unesi poluprecnik:"))
    pi=math.pi
    povrsina=r*r*pi
    print(povrsina)
povrsina_kruga()


