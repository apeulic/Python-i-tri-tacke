class koordinata(object):
    def __init__(self, x, y):
        self.x = x
        self.y = y
    def __str__(self):
        return '<'+str(self.x)+', '+str(self.y)+'>'

a, b = 3, 7
k = koordinata(a, b)
p = koordinata(0, 0)

print(k)
        
