class koordinata(object):
    def __init__(self, x, y):
        self.x = x
        self.y = y
    def __str__(self):
        return '<'+str(self.x)+', '+str(self.y)+'>'
    def rastojanje(self, druga):
        return ((self.x - druga.x)**2 + \
                (self.y - druga.y)**2)**0.5

a, b = 3, 7
k = koordinata(a, b)
p = koordinata(0, 0)

print(k)
print(isinstance(k, koordinata))        
